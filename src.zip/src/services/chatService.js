import api from "./api";

/**
 * Send message to the selected conversation.
 *
 * @param {number|string} chatId
 * @param {string} message
 * @param {string} model
 */
export async function sendMessage(
  chatId,
  message,
  model = "qwen3:8b"
) {
  try {
    if (!chatId) {
      throw new Error("Conversation ID is missing.");
    }

    if (!message?.trim()) {
      throw new Error("Message is empty.");
    }

    const response = await api.post("/chat/", {
      chat_id: chatId,
      message: message,
      model: model,
    });

    const data = response.data;

    console.log("[CHAT RESPONSE]", data);

    if (!data) {
      throw new Error("Empty response from backend.");
    }

    if (data.success === false) {
      throw new Error(
        data.detail ||
        data.error ||
        "Backend returned an error."
      );
    }

    if (typeof data.reply !== "string") {
      throw new Error(
        "Invalid AI response received from backend."
      );
    }

    return data.reply;

  } catch (error) {
    console.error(
      "[CHAT SERVICE ERROR]",
      error
    );

    if (error.response) {
      const data = error.response.data;

      throw new Error(
        data?.detail ||
        data?.error ||
        `Server error: ${error.response.status}`
      );
    }

    if (error.request) {
      throw new Error(
        "Cannot connect to AI backend."
      );
    }

    throw new Error(
      error.message ||
      "Unable to send message."
    );
  }
}