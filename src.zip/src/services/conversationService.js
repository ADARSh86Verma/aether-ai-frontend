import api from "./api";

export async function createConversation() {
  const { data } = await api.post("/conversations/");
  
  return {
    id: data.chat_id,
    title: data.title || "New Chat",
    favorite: false,
  };
}

export async function getConversations() {
  const { data } = await api.get("/conversations/");

  // Backend सीधे array दे या { conversations: [] } दे,
  // दोनों को handle करेंगे.
  const conversations = Array.isArray(data)
    ? data
    : Array.isArray(data?.conversations)
      ? data.conversations
      : [];

  return conversations;
}

export async function getConversation(chatId) {
  const { data } = await api.get(`/conversations/${chatId}`);

  return {
    id: data.id,
    title: data.title || "New Chat",
    messages: Array.isArray(data.messages)
      ? data.messages
      : [],
  };
}

export async function deleteConversation(chatId) {
  const { data } = await api.delete(
    `/conversations/${chatId}`
  );

  return data;
}